# FastAPI---Python
pip install -r requirements.txt

uvicorn main:app --reload


